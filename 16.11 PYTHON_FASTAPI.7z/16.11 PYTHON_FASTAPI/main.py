import sqlite3
import json
from fastapi import FastAPI, Body, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
from typing import List, Optional

# --- 1. Налаштування бази даних ---
DB_NAME = "store.db"

def get_db_connection():
    """Створює з'єднання з базою даних."""
    conn = sqlite3.connect(DB_NAME)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    """Ініціалізує таблиці в базі даних, якщо вони не існують."""
    conn = get_db_connection()
    c = conn.cursor()

    # Таблиця товарів
    c.execute("""
        CREATE TABLE IF NOT EXISTS items (
            id INTEGER PRIMARY KEY,
            name TEXT NOT NULL,
            image_url TEXT,
            price REAL NOT NULL
        )
    """)

    # Таблиця користувачів
    c.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL
        )
    """)

    # Таблиця кошиків
    c.execute("""
        CREATE TABLE IF NOT EXISTS cart (
            id INTEGER PRIMARY KEY,
            username TEXT UNIQUE NOT NULL,
            cartcontent TEXT NOT NULL
        )
    """)

    # Таблиця відгуків
    c.execute("""
        CREATE TABLE IF NOT EXISTS reviews (
            id INTEGER PRIMARY KEY,
            username TEXT NOT NULL,
            content TEXT NOT NULL
        )
    """)

    # Товари більше не додаються автоматично
    c.execute("SELECT COUNT(*) FROM items")
    if c.fetchone()[0] == 0:
        print("База даних ініціалізована. Таблиця товарів порожня.")
        pass

    # Додавання тестового адміна
    c.execute("SELECT COUNT(*) FROM users WHERE username='admin'")
    if c.fetchone()[0] == 0:
        c.execute("INSERT INTO users (username, password) VALUES ('admin', 'adminpass')")
        c.execute("INSERT INTO cart (username, cartcontent) VALUES ('admin', '[]')")

    conn.commit()
    conn.close()

# --- 2. Pydantic Моделі ---
class Item(BaseModel):
    id: int
    name: str
    image_url: str
    price: float

class NewItem(BaseModel):
    name: str = Field(..., max_length=15)
    image_url: str
    price: float = Field(..., gt=0)

class User(BaseModel):
    username: str
    password: str

class LoginUser(BaseModel):
    username: str
    password: str

class CartContentItem(BaseModel):
    id: int
    name: str
    price: float

class CartItemEntry(BaseModel):
    count: int
    item: CartContentItem

class CartUpdate(BaseModel):
    username: str
    cartcontent: List[CartItemEntry]

class Review(BaseModel):
    username: str
    content: str = Field(..., max_length=100)

class StoredReview(BaseModel):
    id: int
    username: str
    content: str


# --- 3. Налаштування FastAPI ---
app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.on_event("startup")
def on_startup():
    """Виконується при запуску сервера."""
    init_db()


# --- 4. Ендпоінти ---

# --- Ендпоінти для Товарів (/items) ---

@app.get("/items/", response_model=List[Item], tags=["Items"])
async def get_items():
    """Повертає список усіх товарів."""
    conn = get_db_connection()
    items = conn.execute("SELECT * FROM items").fetchall()
    conn.close()
    return [dict(item) for item in items]

@app.post("/items/", status_code=status.HTTP_201_CREATED, tags=["Items"])
async def add_item(new_item: NewItem):
    """Додає новий товар у базу даних."""
    if len(new_item.name) > 15:
        raise HTTPException(status_code=400, detail="Name is too long.")

    conn = get_db_connection()
    c = conn.cursor()
    c.execute(
        "INSERT INTO items (name, image_url, price) VALUES (?, ?, ?)",
        (new_item.name, new_item.image_url, new_item.price)
    )
    conn.commit()
    conn.close()
    return {"message": "New item added successfully"}

@app.delete("/items/clear", tags=["Items"], status_code=status.HTTP_200_OK)
async def clear_items_table():
    """Видаляє ВСІ товари з таблиці items."""
    conn = get_db_connection()
    c = conn.cursor()
    c.execute("DELETE FROM items")
    conn.commit()
    conn.close()
    return {"message": "All items have been successfully deleted from the database."}

@app.delete("/items/{item_id}", tags=["Items"], status_code=status.HTTP_200_OK)
async def delete_item_by_id(item_id: int):
    """Видаляє товар за його унікальним ID."""
    conn = get_db_connection()
    c = conn.cursor()

    # Видаляємо товар за ID
    c.execute("DELETE FROM items WHERE id = ?", (item_id,))

    deleted_rows = c.rowcount
    conn.commit()
    conn.close()

    if deleted_rows == 0:
        # Якщо c.rowcount дорівнює 0, товар з таким ID не знайдено
        raise HTTPException(status_code=404, detail=f"Item with ID {item_id} not found.")

    return {"message": f"Item with ID {item_id} deleted successfully."}


# --- Ендпоінти для Користувачів (/users) ---
@app.post("/users/register", tags=["Users"])
async def register_user(new_user: User):
    conn = get_db_connection()
    c = conn.cursor()
    existing_user = c.execute("SELECT * FROM users WHERE username = ?", (new_user.username,)).fetchone()
    if existing_user:
        conn.close()
        raise HTTPException(status_code=409, detail="User already exists!")
    try:
        c.execute(
            "INSERT INTO users (username, password) VALUES (?, ?)",
            (new_user.username, new_user.password)
        )
        c.execute(
            "INSERT INTO cart (username, cartcontent) VALUES (?, ?)",
            (new_user.username, "[]")
        )
        conn.commit()
        conn.close()
        return {"message": "Successfully registered"}
    except Exception as e:
        conn.close()
        print(f"Registration error: {e}")
        raise HTTPException(status_code=500, detail="Server error!")

@app.post("/users/login", tags=["Users"])
async def login_user(user_data: LoginUser):
    conn = get_db_connection()
    user = conn.execute(
        "SELECT * FROM users WHERE username = ? AND password = ?",
        (user_data.username, user_data.password)
    ).fetchone()
    conn.close()
    if user:
        return {"message": "Login Successfull!"}
    else:
        raise HTTPException(status_code=404, detail="No user found or wrong credentials!")

# --- Ендпоінти для Кошика (/cart) ---
@app.get("/cart/{username}", tags=["Cart"])
async def get_cart(username: str):
    conn = get_db_connection()
    cart = conn.execute(
        "SELECT username, cartcontent FROM cart WHERE username = ?",
        (username,)
    ).fetchall()
    conn.close()
    if cart:
        return [dict(row) for row in cart]
    else:
        conn = get_db_connection()
        c = conn.cursor()
        c.execute("INSERT INTO cart (username, cartcontent) VALUES (?, ?)", (username, "[]"))
        conn.commit()
        conn.close()
        return [{"username": username, "cartcontent": "[]"}]

@app.post("/cart/", tags=["Cart"])
async def update_cart(cart_update: CartUpdate):
    conn = get_db_connection()
    c = conn.cursor()
    cartcontent_json_str = json.dumps([item.model_dump() for item in cart_update.cartcontent])
    try:
        c.execute(
            "UPDATE cart SET cartcontent = ? WHERE username = ?",
            (cartcontent_json_str, cart_update.username)
        )
        conn.commit()
        conn.close()
        return {"message": "Updated"}
    except Exception as e:
        conn.close()
        print(f"Cart update error: {e}")
        raise HTTPException(status_code=500, detail="Error updating cart.")

# --- Ендпоінти для Відгуків (/reviews) ---
@app.get("/reviews", response_model=List[StoredReview], tags=["Reviews"])
async def get_reviews():
    conn = get_db_connection()
    reviews = conn.execute("SELECT * FROM reviews").fetchall()
    conn.close()
    return [dict(review) for review in reviews]

@app.post("/reviews/", status_code=status.HTTP_201_CREATED, tags=["Reviews"])
async def add_review(review: Review):
    if len(review.content) > 100:
        raise HTTPException(status_code=400, detail="Review is too long!")
    conn = get_db_connection()
    c = conn.cursor()
    c.execute(
        "INSERT INTO reviews (username, content) VALUES (?, ?)",
        (review.username, review.content)
    )
    conn.commit()
    conn.close()
    return {"message": "Review added!"}

@app.delete("/reviews/{review_id}", tags=["Reviews"])
async def delete_review(review_id: int):
    """Видаляє відгук за його ID."""
    conn = get_db_connection()
    c = conn.cursor()
    c.execute("DELETE FROM reviews WHERE id = ?", (review_id,))
    conn.commit()
    deleted_rows = c.rowcount
    conn.close()

    if deleted_rows == 0:
        raise HTTPException(status_code=404, detail="Review not found")

    return {"message": f"Review with ID {review_id} deleted successfully"}